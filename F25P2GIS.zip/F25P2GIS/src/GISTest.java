import java.io.IOException;
import student.TestCase;

/**
 * 
 * @author Josh Kwen, James Son
 * 
 * @version 10/09/2025
 */
public class GISTest extends TestCase {

    private GIS it;

    /**
     * 
     * Sets up the tests
     */
    public void setUp() {
        it = new GISDB();
    }


    /**
     * 
     * @throws IOException
     */
    public void testRefClearInit() throws IOException {
        assertTrue(it.clear());
    }


    /**
     * 
     * @throws IOException
     */
    public void testRefEmptyPrints() throws IOException {
        assertFuzzyEquals("", it.print());
        assertFuzzyEquals("", it.debug());
        assertFuzzyEquals("", it.info("CityName"));
        assertFuzzyEquals("", it.info(5, 5));
        assertFuzzyEquals("", it.delete("CityName"));
        assertFuzzyEquals("", it.delete(5, 5));
    }


    /**
     * 
     * @throws IOException
     */
    public void testRefBadInput() throws IOException {
        assertFalse(it.insert("CityName", -1, 5));
        assertFalse(it.insert("CityName", 5, -1));
        assertFalse(it.insert("CityName", 100000, 5));
        assertFalse(it.insert("CityName", 5, 100000));
        assertFuzzyEquals("", it.search(-1, -1, -1));
    }


    /**
     * 
     * @throws IOException
     */
    public void testCoordinatesBoundary() throws IOException {
        assertTrue(it.insert("City1", 0, 0));
        assertTrue(it.insert("City2", 32767, 32767));
        assertFalse(it.insert("City3", 32768, 200));
        assertFalse(it.insert("City4", 200, 32768));
    }


    /**
     * 
     * @throws IOException
     */
    public void testSameNameDiffCoord() throws IOException {
        assertTrue(it.insert("Blacksburg", 100, 100));
        assertTrue(it.insert("Blacksburg", 200, 200));
        assertTrue(it.insert("Blacksburg", 90, 90));
        assertFuzzyEquals(
            "2 Blacksburg (90, 90)\n1 Blacksburg (200, 200)\n0Blacksburg (100, 100)\n",
            it.print());
    }


    /**
     * 
     * @throws IOException
     */
    public void testInsertThenClear() throws IOException {
        assertTrue(it.insert("Christiansburg", 50, 50));
        assertTrue(it.clear());
        assertFuzzyEquals("", it.print());
    }


    /**
     * 
     * @throws IOException
     */
    public void testDuplicateCoordinates() throws IOException {
        assertTrue(it.insert("Radford", 90, 90));
        assertFalse(it.insert("Blacksburg", 90, 90));
    }


    /**
     * 
     * @throws IOException
     */
    public void testXDiscriminator() throws IOException {
        assertTrue(it.insert("CityA", 100, 100));
        assertTrue(it.insert("CityB", 99, 101));
        assertTrue(it.insert("CityC", 101, 99));
        assertFuzzyEquals(
            "1 CityB (99, 101)\n0CityA (100, 100)\n1 CityC (101, 99)\n", it
                .debug());
    }


    /**
     * 
     * @throws IOException
     */
    public void testYDiscriminator() throws IOException {
        assertTrue(it.insert("CityA", 200, 200));
        assertTrue(it.insert("CityB", 100, 200));
        assertTrue(it.insert("CityC", 50, 100));
        assertTrue(it.insert("CityD", 150, 400));
        assertFuzzyEquals(
            "2 CityC (50, 100)\n1 CityB (100, 200)\n2 CityD (150, 400)\n0CityA (200, 200)\n",
            it.debug());
    }


    /**
     * 
     * @throws IOException
     */
    public void testBSTNullInsert() throws IOException {
        assertFalse(it.insert(null, 100, 100));
        assertFuzzyEquals("", it.print());
    }


    /**
     * insert rejects null and blank name
     */
    public void testInsertRejectsNullAndBlank() throws IOException {
        assertFalse(it.insert(null, 10, 10));
        assertFalse(it.insert("   ", 10, 10));
    }


    /**
     * delete by coords returns empty when not found
     */
    public void testDeleteCoordNotFoundReturnsEmpty() throws IOException {
        assertFuzzyEquals("", it.delete(999, 999));
    }


    /**
     * delete by name hits break and newline cases
     */
    public void testDeleteNameBreakAndNewline() throws IOException {
        assertFuzzyEquals("", it.delete("NoSuch"));
        assertTrue(it.insert("Twin", 10, 10));
        assertTrue(it.insert("Twin", 20, 20));
        String out = it.delete("Twin");
        assertFuzzyEquals("Twin\nTwin", out);
    }


    /**
     * info by coords returns empty when not found
     */
    public void testInfoXYNotFoundReturnsEmpty() throws IOException {
        assertFuzzyEquals("", it.info(1, 2));
    }


    /**
     * info by name returns empty on null or empty
     */
    public void testInfoNameNullOrEmptyReturnsEmpty() throws IOException {
        assertFuzzyEquals("", it.info((String)null));
        assertFuzzyEquals("", it.info(""));
    }


    /**
     * search returns empty on negative radius
     */
    public void testSearchNegativeRadiusReturnsEmpty() throws IOException {
        assertFuzzyEquals("", it.search(0, 0, -5));
    }

}
